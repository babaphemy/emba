/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
TC_COURSE_ID = "http://C9jEdkWFAVqwN3h4UrE-1Usaq4KPg3Jf_rise"

//
// CourseName for the activity
//
TC_COURSE_NAME = {
  "en-US": "Retail - Supply Chain"
};

//
// CourseDesc for the activity
//
TC_COURSE_DESC = {
  "en-US": "&lt;div data-editor-id=&#34;7fd863af-e1ec-46ea-82ab-3d1c753ecce2&#34;&gt;&lt;p style=&#34;text-align: justify&#34;&gt;This course dives into the critical relationship between retail and supply chain management, exploring how global retail giants like Walmart, Amazon, and Costco achieve operational efficiency, minimize costs, and maximize customer satisfaction. We will focus on supply chain strategies, key technologies, and metrics used in retail, as well as discuss challenges and innovations shaping the future.&lt;/p&gt;&lt;p style=&#34;text-align: justify&#34;&gt;&lt;/p&gt;&lt;h3&gt;&lt;strong&gt;Learning Objectives&lt;/strong&gt;&lt;/h3&gt;&lt;ol&gt;&lt;li&gt;&lt;p&gt;Understand the role of supply chain management in the retail industry.&lt;/p&gt;&lt;/li&gt;&lt;li&gt;&lt;p&gt;Analyze strategies used by leading retailers to optimize supply chain performance.&lt;/p&gt;&lt;/li&gt;&lt;li&gt;&lt;p&gt;Explore key supply chain technologies such as RFID, AI, and IoT.&lt;/p&gt;&lt;/li&gt;&lt;li&gt;&lt;p&gt;Identify challenges in retail supply chains and how companies mitigate risks.&lt;/p&gt;&lt;/li&gt;&lt;li&gt;&lt;p&gt;Apply concepts through case studies and a hands-on simulation exercise.&lt;/p&gt;&lt;/li&gt;&lt;/ol&gt;&lt;/div&gt;"
};
